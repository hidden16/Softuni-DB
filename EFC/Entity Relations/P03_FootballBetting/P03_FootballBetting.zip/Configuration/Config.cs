﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Configuration
{
    public static class Config
    {
        public const string ConnectionString = @"Server=IKSAN\SQLEXPRESS;Database=FootballBetting;Integrated Security=True;";
    }
}
