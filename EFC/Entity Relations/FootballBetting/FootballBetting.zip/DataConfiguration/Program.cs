﻿using System;

namespace DataConfiguration
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
