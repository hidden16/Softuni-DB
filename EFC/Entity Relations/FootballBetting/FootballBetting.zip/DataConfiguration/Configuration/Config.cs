﻿namespace DataConfiguration.Configuration
{
    public static class Config
    {
        public const string ConnectionString = @"Server=IKSAN\SQLEXPRESS;Database=FootballBetting;Integrated Security=True;";
    }
}