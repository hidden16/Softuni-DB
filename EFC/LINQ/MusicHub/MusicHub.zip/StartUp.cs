﻿namespace MusicHub
{
    using System;
    using System.Linq;
    using System.Text;
    using Data;
    using Initializer;
    using Microsoft.EntityFrameworkCore;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            MusicHubDbContext context =
                new MusicHubDbContext();

            DbInitializer.ResetDatabase(context);
            var input = int.Parse(Console.ReadLine());
            var result = ExportAlbumsInfo(context, input);
            result = ExportSongsAboveDuration(context, input);
            Console.WriteLine(result);
        }

        public static string ExportAlbumsInfo(MusicHubDbContext context, int producerId)
        {
            StringBuilder sb = new StringBuilder();
            var albums = context.Albums
                 .Include(x => x.Producer)
                 .Where(x => x.ProducerId == producerId)
                 .ToList();
            foreach (var album in albums.OrderByDescending(x => x.Price))
            {
                var i = 1;
                sb.AppendLine($"-AlbumName: {album.Name}");
                sb.AppendLine($"-ReleaseDate: {album.ReleaseDate.ToString("MM/dd/yyyy")}");
                sb.AppendLine($"-ProducerName: {album.Producer.Name}");
                sb.AppendLine($"-Songs:");
                foreach (var song in album.Songs.OrderByDescending(x => x.Name).ThenBy(x => x.Writer.Name))
                {
                    sb.AppendLine($"---#{i}");
                    sb.AppendLine($"---SongName: {song.Name}");
                    sb.AppendLine($"---Price: {song.Price:f2}");
                    sb.AppendLine($"---Writer: {song.Writer.Name}");
                    i++;
                }
                sb.AppendLine($"-AlbumPrice: {album.Price:f2}");
            }
            return sb.ToString().TrimEnd();
        }

        public static string ExportSongsAboveDuration(MusicHubDbContext context, int duration)
        {
            StringBuilder sb = new StringBuilder();
            TimeSpan t2 = new TimeSpan(0, 0, duration);
            var songs = context.Songs
                            .Include(x => x.SongPerformers)
                            .ThenInclude(x => x.Performer)
                            .Include(x => x.Writer)
                            .Where(x => x.Duration > t2)
                            .ToList();
            var performer = string.Empty;
            var i = 1;
            foreach (var song in songs.OrderBy(x => x.Name).ThenBy(x => x.Writer.Name).ThenBy(x => x.SongPerformers.OrderBy(x => x.Performer.FirstName)))
            {
                sb.AppendLine($"-Song #{i}");
                sb.AppendLine($"---SongName: {song.Name}");
                sb.AppendLine($"---Writer: {song.Writer.Name}");
                //if (song.SongPerformers.Count() == 0)
                //{
                //    performer = "";
                //}
                //else
                //{
                //    foreach (var performers in song.SongPerformers)
                //    {
                //        performer = performers.Performer.FirstName + " " + performers.Performer.LastName;
                //        break;
                //    }
                //}
                sb.AppendLine($"---Performer: {song.SongPerformers.Select(x=>$"{x.Performer.FirstName} {x.Performer.LastName}").FirstOrDefault()}");
                sb.AppendLine($"---AlbumProducer: {song.Album.Producer.Name}");
                sb.AppendLine($"---Duration: {song.Duration.ToString("c")}");
                i++;
            }
            return sb.ToString().TrimEnd();
        }
    }
}

/*
 * 
 * @"-Song #1
---SongName: Away
---Writer: Norina Renihan
---Performer: Lula Zuan
---AlbumProducer: Georgi Milkov
---Duration: 00:05:35
-Song #2
---SongName: Bentasil
---Writer: Mik Jonathan
---Performer: Zabrina Amor
---AlbumProducer: Dobromir Slavchev
---Duration: 00:04:03
-Song #3
---SongName: Carvedilol
---Writer: Chloe Trayhorn
---Performer: Tine Althorp
---AlbumProducer: Evtim Miloshev
---Duration: 00:02:39
-Song #4
---SongName: Cough Relief
---Writer: Jessie Townby
---Performer: Peter Bree
---AlbumProducer: Evgeni Dimitrov
---Duration: 00:10:34
-Song #5
---SongName: Crayola Wild Blue
---Writer: Holly Coppen
---Performer: Tine Althorp
---AlbumProducer: Dobromir Slavchev
---Duration: 00:01:58
-Song #6
---SongName: Cry Me A River
---Writer: Kara-lynn Sharpous
---Performer: Georgia Winchurch
---AlbumProducer: Evtim Miloshev
---Duration: 00:04:20
-Song #7
---SongName: Don't call me up
---Writer: Jessie Townby
---Performer: Georgia Winchurch
---AlbumProducer: Dobromir Slavchev
---Duration: 00:05:20
-Song #8
---SongName: Dorzolamide HCl
---Writer: Norina Renihan
---Performer: 
---AlbumProducer: Evtim Miloshev
---Duration: 00:02:50
-Song #9
---SongName: Hydralazine Hydroch
---Writer: Sibelle Hanton
---Performer: Gennifer Lopez
---AlbumProducer: F.O.
---Duration: 00:09:54
-Song #10
---SongName: Ibuprofen
---Writer: Stanford Daykin
---Performer: 
---AlbumProducer: Evgeni Dimitrov
---Duration: 00:01:04
-Song #11
---SongName: In the end
---Writer: Verine Eschalotte
---Performer: Lula Zuan
---AlbumProducer: Evgeni Dimitrov
---Duration: 00:02:11
-Song #12
---SongName: In the start
---Writer: Rosalyn Humphris
---Performer: Alidia Horsewood
---AlbumProducer: Rolph Nibley
---Duration: 00:03:15
-Song #13
---SongName: It is my life
---Writer: Stanford Daykin
---Performer: Alidia Horsewood
---AlbumProducer: Evgeni Dimitrov
---Duration: 00:06:11
-Song #14
---SongName: Just the two of us
---Writer: Padget Steptowe
---Performer: Dasi Pirrey
---AlbumProducer: Evtim Miloshev
---Duration: 00:02:40
-Song #15
---SongName: Kids SPF 60
---Writer: Bili Franek
---Performer: Gilligan Caney
---AlbumProducer: Jana Karaivanova
---Duration: 00:01:17
-Song #16
---SongName: La Vaquita
---Writer: Maitilde Sangar
---Performer: Zabrina Amor
---AlbumProducer: Georgi Milkov
---Duration: 00:08:32
-Song #17
---SongName: Levothyroxine Sodium
---Writer: Carol Mitchell
---Performer: Gennifer Lopez
---AlbumProducer: Evgeni Dimitrov
---Duration: 00:10:41
-Song #18
---SongName: Lose Yourself
---Writer: Chelsy Pennyman
---Performer: Alidia Horsewood
---AlbumProducer: Dobromir Slavchev
---Duration: 00:03:30
-Song #19
---SongName: Medique Diphen
---Writer: Rosalyn Humphris
---Performer: Gennifer Lopez
---AlbumProducer: F.O.
---Duration: 00:09:31
-Song #20
---SongName: Morning After
---Writer: Linnie Petrolli
---Performer: 
---AlbumProducer: Jana Karaivanova
---Duration: 00:04:23
-Song #21
---SongName: Numb
---Writer: Kara-lynn Sharpous
---Performer: Alidia Horsewood
---AlbumProducer: Evgeni Dimitrov
---Duration: 00:04:11
-Song #22
---SongName: Personal
---Writer: Gleda Messum
---Performer: Lula Zuan
---AlbumProducer: Jana Karaivanova
---Duration: 00:02:40
-Song #23
---SongName: Quinapril
---Writer: Linnie Petrolli
---Performer: Gilligan Caney
---AlbumProducer: Georgi Milkov
---Duration: 00:10:31
-Song #24
---SongName: Ride it
---Writer: Lusa Steers
---Performer: Lula Zuan
---AlbumProducer: Georgi Milkov
---Duration: 00:04:35
-Song #25
---SongName: River
---Writer: Quillan Grover
---Performer: Alidia Horsewood
---AlbumProducer: Georgi Milkov
---Duration: 00:03:10
-Song #26
---SongName: rx act pain relief
---Writer: Chelsy Pennyman
---Performer: Tine Althorp
---AlbumProducer: Dobromir Slavchev
---Duration: 00:03:39
-Song #27
---SongName: Say It Right
---Writer: Petko Matisse
---Performer: Lula Zuan
---AlbumProducer: Georgi Milkov
---Duration: 00:04:35
-Song #28
---SongName: Tiempo
---Writer: Norina Renihan
---Performer: Lula Zuan
---AlbumProducer: Georgi Milkov
---Duration: 00:05:35
-Song #29
---SongName: Wait For A Minute
---Writer: Verine Eschalotte
---Performer: Dasi Pirrey
---AlbumProducer: Evtim Miloshev
---Duration: 00:04:20
-Song #30
---SongName: Water Additive
---Writer: Quillan Grover
---Performer: Gilligan Caney
---AlbumProducer: Evtim Miloshev
---Duration: 00:02:33
-Song #31
---SongName: What Goes Around
---Writer: Maitilde Sangar
---Performer: Peter Bree
---AlbumProducer: Georgi Milkov
---Duration: 00:03:23
-Song #32
---SongName: Wide Awake
---Writer: Marlee Olivet
---Performer: Alidia Horsewood
---AlbumProducer: Evgeni Dimitrov
---Duration: 00:04:11"
 * 
 */