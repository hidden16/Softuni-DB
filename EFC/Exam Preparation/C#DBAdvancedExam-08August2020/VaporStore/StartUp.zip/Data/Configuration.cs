﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
			@"Server=IKSAN\SQLEXPRESS;Database=VaporStore;Trusted_Connection=True";
	}
}