﻿namespace Artillery.Data.Models.Enums
{
    public enum GunType
    {
        Howitzer = 1,
        Mortar = 2,
        FieldGun = 3,
        AntiAircraftGun = 4,
        MountainGun = 5,
        AntiTankGun = 6
    }
}
