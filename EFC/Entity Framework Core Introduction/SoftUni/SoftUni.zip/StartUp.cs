﻿using System;

namespace SoftUni
{
    internal class StartUp
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
