﻿using SoftUni.Data;
using System;
using System.Linq;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            SoftUniContext context = new SoftUniContext();
            string result = SoftUniDatabaseCommands.GetEmployeesFullInformation(context);
            Console.WriteLine(result);
        }
    }
}
