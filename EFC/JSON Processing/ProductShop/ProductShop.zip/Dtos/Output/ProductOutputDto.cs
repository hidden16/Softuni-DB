﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.Dtos.Output
{
    public class ProductOutputDto
    {
        public string name { get; set; }
        public decimal price { get; set; }
        public string seller { get; set; }
    }
}
