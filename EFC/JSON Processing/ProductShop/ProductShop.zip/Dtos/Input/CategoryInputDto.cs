﻿namespace ProductShop.Dtos.Input
{
    public class CategoryInputDto
    {
        public string Name { get; set; }
    }
}
